
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{

    [SerializeField] private float speed;
    [SerializeField] private float jumpPower;
    [SerializeField] private LayerMask groundLayer;
    private Rigidbody2D body;
    private Animator anim;
    private BoxCollider2D boxCollider;
    private bool playerFacingRight = true;
    private float horizontalInput;


    private void Awake()
    {
        // PlayerMovement script is attached to the player object get component checks
        // the player object for a component of type rigidbody2D and store in body variable
        // Grab reference for rigidbody and animator from object
        body = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        boxCollider = GetComponent<BoxCollider2D>();
    }

    private void Update()
    {
        horizontalInput = Input.GetAxis("Horizontal");
        body.velocity = new Vector2(horizontalInput * speed, body.velocity.y);

        // Flip the player when moving left-right
        if (horizontalInput > 0.01f && !playerFacingRight)
            Flip();
        else if (horizontalInput < -0.01f && playerFacingRight)
            Flip();

        // Check to see if player can jump
        if (Input.GetKey(KeyCode.Space) && isGrounded())
            Jump();

        // Check if input done to shoot


        // Set animator parameters
        anim.SetBool("run", horizontalInput != 0);      // logical check to see if we press move keys. Horizontal input = 0 when we press nothing.
        anim.SetBool("grounded", isGrounded());
    }

    private void Flip()
    {
        playerFacingRight = !playerFacingRight;
        transform.Rotate(0f, 180f, 0f);
    }

    private void Jump()
    {
        body.velocity = new Vector2(body.velocity.x, jumpPower);
        anim.SetTrigger("jump");
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name.Equals("PlatformVerticalPattern"))
            this.transform.parent = collision.transform;
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.name.Equals("PlatformVerticalPattern"))
            this.transform.parent = null;
    }

    public bool isGrounded()
    {
        RaycastHit2D raycastHit = Physics2D.BoxCast(boxCollider.bounds.center, boxCollider.bounds.size, 0, Vector2.down, 0.1f, groundLayer);
        return raycastHit.collider != null;
    }

}
