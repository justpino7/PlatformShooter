using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class CountdownTimer : MonoBehaviour
{
    public int countdownTime;           // can put more or less than 3 in inspector
    public TMP_Text countdownDisplay;
    public TimeController tc;

    private void Start()
    {
        StartCoroutine(CountdownToStart());
    }

    IEnumerator CountdownToStart()
    {
        while (countdownTime > 0)
        {
            countdownDisplay.text = countdownTime.ToString();
            yield return new WaitForSecondsRealtime(1f);            // waitseconds doesn't work with timeScale
            countdownTime--;
        }

        tc.BeginGame();
        countdownDisplay.text = "Over!";

        yield return new WaitForSeconds(1f);
        countdownDisplay.gameObject.SetActive(false);

    }
}
