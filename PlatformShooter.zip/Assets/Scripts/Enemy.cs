using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
//using UnityEngine.Events;


public class Enemy : MonoBehaviour
{
    private EnemySpawning enemySpawning;

    public int health = 1;

    public float enemyLifetime = 5f;       // time before enemy disappears if not death

    public GameObject deathEffect;

    public GameObject disappearEffect;

    public int attackDamage = 1;

   // public UnityEvent<Enemy> OnEnemyKilled;

    //public Text scoreText;

    public int playerPoints;

    void Start()
    {
        StartCoroutine(Disappear());
        //StartCoroutine(Rotate());

        // initialize text to display current score
        //scoreText.text = "Total Score: " + PlayerScore.totalScore;
    }

    public void TakeDamage(int damage)
    {
        health -= damage;

        if (health <= 0)
        {
            Die();
        }
    }

     void Die()
    {
        Instantiate(deathEffect, transform.position, Quaternion.identity);
        Debug.Log(deathEffect.name);
        if(deathEffect.name == "DeathEffectGhost")
        {
            PlayerScore.totalScore += 1;
            playerPoints = PlayerScore.totalScore;
            Debug.Log(deathEffect.name);
            Debug.Log(PlayerScore.totalScore);
            //scoreText.text = "Total Score: " + PlayerScore.totalScore;
            //OnEnemyKilled.Invoke(this);
        }
        if (deathEffect.name == "DeathEffectSkeleton2")
        {
            PlayerScore.totalScore += 1;
            playerPoints = PlayerScore.totalScore;
            Debug.Log(deathEffect.name);
            Debug.Log(PlayerScore.totalScore);
            //scoreText.text = "Total Score: " + PlayerScore.totalScore;
            //OnEnemyKilled.Invoke(this);
        }
        if (deathEffect.name == "DeathEffectWitch")
        {
            PlayerScore.totalScore += 3;
            playerPoints = PlayerScore.totalScore;
            Debug.Log(deathEffect.name);
            Debug.Log(PlayerScore.totalScore);
            //scoreText.text = "Total Score: " + PlayerScore.totalScore;
            //OnEnemyKilled.Invoke(this);
        }
        Destroy(gameObject);

        // spawner logic
        enemySpawning = FindObjectOfType<EnemySpawning>();
        enemySpawning.enemiesInRoom--;
        if (enemySpawning.spawnTime <= 0 && enemySpawning.enemiesInRoom <= 0)
        {
            enemySpawning.spawnerDone = true;
        }
    }

    // Make enemies disappear if they are still alive after a certain amount of time
    IEnumerator Disappear()
    {
        yield return new WaitForSeconds(enemyLifetime);
        Instantiate(disappearEffect, transform.position, Quaternion.identity);
        Destroy(gameObject);
        
        // spawner logic
        enemySpawning = FindObjectOfType<EnemySpawning>();
        enemySpawning.enemiesInRoom--;
    }

    /**
    IEnumerator Rotate()
    {
        yield return new WaitForSeconds(enemyLifetime / 4);
        transform.Rotate(0f, 180f, 0f);
    }
    **/



}
