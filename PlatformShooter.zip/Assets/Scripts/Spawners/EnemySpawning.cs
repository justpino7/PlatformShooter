using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawning : MonoBehaviour
{

    public GameObject[] spawnPoints;        // store places where enemies can spawn
    GameObject currentPoint;        // point to chose an enemy
    int index;      // handle the actual position in the array where we chose to spawn

    public GameObject[] enemies;        // Store our enemies from which we can chose one randomly
    public float minTimeBtwSpawns;
    public float maxTimeBtwSpawns;
    public bool canSpawn;       // can the spawner actually spawn 
    public float spawnTime;     // how long we'll be spawning enemies for
    public int enemiesInRoom;   // track when the spawner is done
    public bool spawnerDone;
    public GameObject spawnerDoneGameObject;    // active whenever spawner has been completed/is done

    private void Start()
    {
        Invoke("SpawnEnemy", 0.5f);
    }

    private void Update()
    {
        if (canSpawn)
        {
            spawnTime -= Time.deltaTime;
            if(spawnTime < 0)
            {
                canSpawn = false;
                spawnerDoneGameObject.SetActive(true);      // timer for spawning is done
            }
        }
    }
    void SpawnEnemy()
    {
        index = Random.Range(0, spawnPoints.Length);    // chose a random spawn point and store it in index
        currentPoint = spawnPoints[index];      // current point where enemy will spawn
        float timeBtwSpawns = Random.Range(minTimeBtwSpawns, maxTimeBtwSpawns);     // random value between our two variables

        if(canSpawn)
        {
            Instantiate(enemies[Random.Range(0, enemies.Length)], currentPoint.transform.position, Quaternion.identity);
            enemiesInRoom++;
        }

        Invoke("SpawnEnemy", timeBtwSpawns);    // how frequently we want our enemies to spawn
        if(spawnerDone)
        {
            spawnerDoneGameObject.SetActive(true);      // Done spawning
        }
    }
}
