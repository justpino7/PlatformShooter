using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeController : MonoBehaviour
{
    public bool gameStarted = false;
    private void Awake()
    {
        Time.timeScale = 1f;
    }

    public void BeginGame()
    {
        Time.timeScale = 1f;
        gameStarted = true;
    }
}
