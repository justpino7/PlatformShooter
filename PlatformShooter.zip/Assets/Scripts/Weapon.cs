using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : MonoBehaviour
{
    public float attackCooldown;
    public float cooldownTimer = Mathf.Infinity;
    public Transform firePoint;
    public GameObject bulletPrefab;

    void Update()
    {
        if (Input.GetButtonDown("Fire1") && cooldownTimer >�attackCooldown)
        {
            Shoot();
        }

        cooldownTimer += Time.deltaTime;
    }

    void Shoot()
    {
        // shooting logic
        Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
        cooldownTimer = 0;
    }
}
