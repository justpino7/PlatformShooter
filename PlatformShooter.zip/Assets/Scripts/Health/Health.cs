using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Health : MonoBehaviour
{
    [SerializeField] private float startingHealth;
    public float currentHealth { get; private set; }
    private Animator anim;
    private bool dead;
    private Rigidbody2D rb;

    private void Awake()
    {
        currentHealth = startingHealth;
        anim = GetComponent<Animator>();
    }

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }
    public void playerDamaged(float _damage)
    {
        currentHealth = Mathf.Clamp(currentHealth - _damage, 0, startingHealth);

        if (currentHealth > 0)
        {
            anim.SetTrigger("hurt");
            //we could implement iframes here
        }
        else
        {
            if (!dead)
            {
                anim.SetTrigger("die");
                rb.constraints = RigidbodyConstraints2D.FreezePositionX;   // lock player movement on death
                dead = true;
                StartCoroutine(BackToMenuOnDeath());
            }
        }
    }

    IEnumerator BackToMenuOnDeath()
    {
        yield return new WaitForSeconds(3f);
        SceneManager.LoadScene(0);
    }

    /** test to see hearts become black with damage
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.N))
            playerDamaged(1);
    }
    **/
}

