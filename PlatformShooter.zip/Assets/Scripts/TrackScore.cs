using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrackScore : MonoBehaviour
{
    public UnityEngine.UI.Text finalScoring;

    //public Text scoreText;

    // initialize text to display current score
    //scoreText.text = "Total Score: " + PlayerScore.totalScore;

    void Start()
    {
        
    }


    void Update()
    {

        //scoreText.text = "Total Score: " + PlayerScore.totalScore;
    }
}
