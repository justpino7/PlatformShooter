using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlayerScore : MonoBehaviour
{
    public static int totalScore;
    private TextMeshProUGUI updatedScore;

    void Start()
    {
        updatedScore = GetComponent<TextMeshProUGUI>();
    }

    public void UpdateScore(Enemy enemy)
    {
        updatedScore.text = enemy.playerPoints.ToString();             // Changes the default text ("0") to the playerPoints variable from the Enemy script
    }

}
